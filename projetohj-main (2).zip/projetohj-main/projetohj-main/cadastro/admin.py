from django.contrib import admin

# Register your models here.
from .models import Pessoa

admin.site.register(Pessoa)