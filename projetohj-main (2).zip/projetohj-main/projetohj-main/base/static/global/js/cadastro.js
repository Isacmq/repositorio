document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('loginForm');
    form.addEventListener('submit', (e) => {
      const username = form.elements['username'].value.trim();
      const password = form.elements['password'].value;
  
      if (username === '' || password.length < 8) {
        e.preventDefault();
        alert('Por favor, insira usuário e senha (mínimo 8 caracteres).');
        return false;
      }
      // Aqui você pode adicionar chamadas AJAX ou feedback visual
      return true;
    });
  });
  