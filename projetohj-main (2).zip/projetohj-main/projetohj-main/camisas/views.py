from django.shortcuts import render

# Create your views here.
def camisas(request):
    contexto = {
        'titulo' : 'Style | camisas'
    }
    return render(request, 
                  'camisas/index.html',
                  contexto,)