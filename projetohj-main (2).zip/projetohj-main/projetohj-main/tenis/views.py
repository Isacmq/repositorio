from django.shortcuts import render

# Create your views here.
def tenis(request):
    contexto = {
        'titulo' : 'Style | tenis'
    }
    return render(request, 
                  'tenis/index.html',
                  contexto)