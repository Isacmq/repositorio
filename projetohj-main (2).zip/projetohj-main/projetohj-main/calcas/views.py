from django.shortcuts import render

# Create your views here.
def calcas(request):
    contexto = {
        'titulo' : 'Style | calcas'
    }
    return render(request, 
     'calcas/index.html',
            contexto,
     )