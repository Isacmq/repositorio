# Create your views here.
from django.shortcuts import render

# Create your views here.
def relogios(request):
    contexto = {
        'titulo' : 'Style | relogios'
    }
    return render(request, 
                  'relogios/index.html',
                  contexto,
                  )