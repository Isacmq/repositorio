from django.apps import AppConfig


class TenisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tenis'
