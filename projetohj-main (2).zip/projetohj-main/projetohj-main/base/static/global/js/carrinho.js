document.addEventListener('DOMContentLoaded', function() {
    const carrinhoToggle = document.querySelector('.carrinho-toggle');
    const carrinhoContainer = document.querySelector('.carrinho-container');
    const fecharCarrinho = document.querySelector('.fechar-carrinho');
    const carrinhoItems = document.querySelector('.carrinho-items');
    const totalElement = document.querySelector('.total-valor');
    const carrinhoQtd = document.querySelector('.carrinho-qtd');
    
    let carrinho = [];
    
    // Abrir/fechar carrinho
    carrinhoToggle.addEventListener('click', () => {
      carrinhoContainer.classList.add('ativo');
    });
    
    fecharCarrinho.addEventListener('click', () => {
      carrinhoContainer.classList.remove('ativo');
    });
    
    // Adicionar ao carrinho
    document.querySelectorAll('.btn-carrinho').forEach(button => {
      button.addEventListener('click', () => {
        const nome = button.getAttribute('data-nome');
        const preco = parseFloat(button.getAttribute('data-preco'));
        const imagem = button.getAttribute('data-imagem');
        
        // Verificar se o item já está no carrinho
        const itemExistente = carrinho.find(item => item.nome === nome);
        
        if (itemExistente) {
          itemExistente.quantidade++;
        } else {
          carrinho.push({
            nome,
            preco,
            imagem,
            quantidade: 1
          });
        }
        
        atualizarCarrinho();
        carrinhoContainer.classList.add('ativo');
      });
    });
    
    // Atualizar carrinho
    function atualizarCarrinho() {
      carrinhoItems.innerHTML = '';
      let total = 0;
      let totalItens = 0;
      
      carrinho.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.classList.add('carrinho-item');
        
        itemElement.innerHTML = `
          <img src="${item.imagem}" alt="${item.nome}" class="carrinho-item-img">
          <div class="carrinho-item-info">
            <h4>${item.nome}</h4>
            <p class="carrinho-item-preco">R$ ${item.preco.toFixed(2)}</p>
            <div class="carrinho-item-quantidade">
              <button class="quantidade-btn menos" data-nome="${item.nome}">-</button>
              <input type="text" class="quantidade-input" value="${item.quantidade}" readonly>
              <button class="quantidade-btn mais" data-nome="${item.nome}">+</button>
            </div>
            <button class="remover-item" data-nome="${item.nome}">Remover</button>
          </div>
        `;
        
        carrinhoItems.appendChild(itemElement);
        total += item.preco * item.quantidade;
        totalItens += item.quantidade;
      });
      
      totalElement.textContent = total.toFixed(2);
      carrinhoQtd.textContent = totalItens;
      
      // Adicionar eventos para os novos botões
      document.querySelectorAll('.menos').forEach(button => {
        button.addEventListener('click', () => {
          const nome = button.getAttribute('data-nome');
          const item = carrinho.find(item => item.nome === nome);
          
          if (item.quantidade > 1) {
            item.quantidade--;
          } else {
            carrinho = carrinho.filter(item => item.nome !== nome);
          }
          
          atualizarCarrinho();
        });
      });
      
      document.querySelectorAll('.mais').forEach(button => {
        button.addEventListener('click', () => {
          const nome = button.getAttribute('data-nome');
          const item = carrinho.find(item => item.nome === nome);
          item.quantidade++;
          atualizarCarrinho();
        });
      });
      
      document.querySelectorAll('.remover-item').forEach(button => {
        button.addEventListener('click', () => {
          const nome = button.getAttribute('data-nome');
          carrinho = carrinho.filter(item => item.nome !== nome);
          atualizarCarrinho();
        });
      });
    }
    
    // Finalizar compra
    document.querySelector('.finalizar-compra').addEventListener('click', () => {
      if (carrinho.length === 0) {
        alert('Seu carrinho está vazio!');
      } else {
        alert(`Compra finalizada! Total: R$ ${totalElement.textContent}`);
        carrinho = [];
        atualizarCarrinho();
      }
    });
  });